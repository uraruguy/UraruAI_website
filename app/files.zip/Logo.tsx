// Logo.tsx - Uraru AI Logo Component
// Usage: <UraruLogo width={160} /> or <UraruBear size={40} />

export function UraruLogo({ width = 160 }: { width?: number }) {
  const height = Math.round(width * 0.29)
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: Math.round(width * 0.08) }}>
      <UraruBear size={height} />
      <span style={{
        fontFamily: 'system-ui, sans-serif',
        fontWeight: 900,
        fontSize: height * 0.7,
        color: '#F0EDE4',
        letterSpacing: '-0.02em',
        lineHeight: 1,
      }}>
        Uraru <span style={{ color: '#00C4CF' }}>AI</span>
      </span>
    </div>
  )
}

export function UraruBear({ size = 40 }: { size?: number }) {
  return (
    <img
      src="/logo-bear.png"
      width={size}
      height={size}
      alt="Uraru AI"
      style={{ objectFit: 'contain' }}
    />
  )
}
